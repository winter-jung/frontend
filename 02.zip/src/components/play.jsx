// 플레이화면 (유튜브 영상)
function Play(){
    return(
<div>

</div>
    )
}

export default Play ;